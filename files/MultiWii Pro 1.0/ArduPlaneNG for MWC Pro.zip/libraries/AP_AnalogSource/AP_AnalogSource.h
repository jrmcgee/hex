
#ifndef __AP_ANALOG_SOURCE_H__
#define __AP_ANALOG_SOURCE_H__

#include "AP_AnalogSource_PIRATES.h"
#include "AP_AnalogSource_Arduino.h"

#endif // __AP_ANALOG_SOURCE_H__
