See the RCG thread below to keep up to date and to discuss this app.

http://www.rcgroups.com/forums/showthread.php?t=1792200

Thanks!!!
KKUSA
*MonSTeR*